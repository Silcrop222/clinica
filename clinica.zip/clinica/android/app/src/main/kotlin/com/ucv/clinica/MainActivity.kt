package com.ucv.clinica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
