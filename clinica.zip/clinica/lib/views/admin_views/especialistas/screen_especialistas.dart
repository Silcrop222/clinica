import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:clinica/viewmodels/specialists_viewmodel.dart';
import 'package:clinica/views/admin_views/especialistas/form_especialistas.dart';
import 'package:clinica/models/app_color.dart'; // Asegúrate de importar tu clase de colores

class SpecialistScreenState extends StatefulWidget {
  @override
  _SpecialistScreenState createState() => _SpecialistScreenState();
}

class _SpecialistScreenState extends State<SpecialistScreenState> {
  @override
  void initState() {
    super.initState();
    // Llamada inicial para cargar los especialistas
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<SpecialistsViewModel>(context, listen: false)
          .fetchSpecialists();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de especialistas',
            style: TextStyle(color: AppColors.textPrimary)),
        backgroundColor: AppColors.primary,
      ),
      body: Consumer<SpecialistsViewModel>(
        builder: (context, viewModel, child) {
          if (viewModel.isLoading) {
            return Center(
                child: CircularProgressIndicator(color: AppColors.primary));
          }

          if (viewModel.specialist.isEmpty) {
            return Center(
                child: Text('No hay especialistas disponibles',
                    style: TextStyle(color: AppColors.textSecondary)));
          }

          return ListView.builder(
            itemCount: viewModel.specialist.length,
            itemBuilder: (context, index) {
              final specialists = viewModel.specialist[index];
              return Card(
                margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 1,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: specialists.urlFoto.isNotEmpty // Revisa si urlFoto no está vacía
                              ? Image.network(
                            specialists.urlFoto,
                            fit: BoxFit.cover,
                            height: 100,
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Center(child: CircularProgressIndicator());
                            },
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(Icons.error, color: Colors.red, size: 40);
                            },
                          )
                              : Container(
                            color: AppColors.inputBackground,
                            height: 100,
                            child: Icon(Icons.image_not_supported,
                                size: 40,
                                color: AppColors.textSecondary),
                          ),
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        flex: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              specialists.firstName,
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text('Nombre: ${specialists.firstName}',
                                style:
                                    TextStyle(color: AppColors.textSecondary)),
                            SizedBox(height: 4),
                            Text('Especialista: ${specialists.info}',
                                style:
                                    TextStyle(color: AppColors.textSecondary)),
                          ],
                        ),
                      ),
                      IconButton(
                        icon:
                            Icon(Icons.delete, color: AppColors.textSecondary),
                        onPressed: () {
                          _showDeleteConfirmationDialog(context, specialists);
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.edit, color: AppColors.primary),
                        onPressed: () {
                          // Navegar al formulario de edición, pasando el paquete actual
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => EspecialistFormScreen(
                                  specialist: specialists),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navega al formulario para registrar un nuevo paquete sin pasar un paquete existente
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => EspecialistFormScreen()),
          );
        },
        child: Icon(Icons.add),
        backgroundColor: AppColors.primary,
        tooltip: 'Registrar nuevo paquete',
      ),
    );
  }

  void _showDeleteConfirmationDialog(BuildContext context, specialist) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Eliminar Paquete',
              style: TextStyle(color: AppColors.textPrimary)),
          content: Text('¿Estás seguro de que deseas eliminar este paquete?',
              style: TextStyle(color: AppColors.textSecondary)),
          actions: [
            TextButton(
              child:
                  Text('Cancelar', style: TextStyle(color: AppColors.primary)),
              onPressed: () {
                Navigator.of(context).pop(); // Cierra el diálogo
              },
            ),
            TextButton(
              child: Text('Eliminar', style: TextStyle(color: Colors.red)),
              onPressed: () {
                // Llama al método para eliminar el paquete
                Provider.of<SpecialistsViewModel>(context, listen: false)
                    .deleteSpecialist(specialist
                        .id); // Asegúrate de tener un método de eliminación
                Navigator.of(context).pop(); // Cierra el diálogo
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Paquete eliminado exitosamente',
                        style: TextStyle(color: AppColors.textPrimary)),
                  ),
                );
              },
            ),
          ],
        );
      },
    );
  }
}
